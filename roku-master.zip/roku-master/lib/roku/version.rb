module Roku
  VERSION = "0.0.4"
end
